//package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import Appn.*;;

public final class inbox_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  Appn.MsgForm[] mf; 
  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Language\" content=\"en-us\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">\r\n");
      out.write("<title>username \r\n");
      out.write("signout</title>\r\n");
      out.write("\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("onload = function() {\r\n");
      out.write("    if (!document.getElementsByTagName || !document.createTextNode) return;\r\n");
      out.write("    var rows = document.getElementById('table1').getElementsByTagName('tbody')[0].getElementsByTagName('tr');\r\n");
      out.write("    for (i = 1; i < rows.length; i++) {\r\n");
      out.write("        rows[i].onclick = function() {\r\n");
      out.write("        var v=\"\"+this.rowIndex;\r\n");
      out.write("        document.forms[0].index.value=v;\r\n");
      out.write("          document.forms[0].action=\"http://localhost:8080/Phising/Msg\";\r\n");
      out.write("          document.forms[0].submit();\r\n");
      out.write("      }\r\n");
      out.write("    }\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("\r\n");
      out.write("<body>\r\n");
      out.write("\r\n");
      out.write("<form method=\"get\">\r\n");
      out.write("<div style=\"position: absolute; width: 45px; height: 48px; z-index: 2; left:710px; top:181px\" id=\"layer2\">\r\n");
      out.write("<div style=\"position: absolute; width: 834px; height: 100px; z-index: 1; left: -731px; top: -184px\" id=\"layer3\">\r\n");
      out.write("<div style=\"position: absolute; width: 172px; height: 28px; z-index: 1; left: 329px; top: 49px\" id=\"layer7\">\r\n");
      out.write("<b><font size=\"7\" color=\"#FFFFFF\" face=\"Chiller\">Global Mail</font></b></div>\r\n");
      out.write("<img src=\"image/in.jpg\"></div>\r\n");
      out.write("&nbsp;</div>\r\n");
      out.write("<p><font color=\"#970000\">\r\n");
      out.write("</font>\r\n");
      out.write("<font color=\"#970000\"></font></a></font></p>\r\n");
      out.write("<div style=\"position: absolute; width: 669px; height: 169px; z-index: 1; left:2px; top:141px\" id=\"layer1\">\r\n");
      out.write("\t\r\n");
      out.write("\t<blockquote>\r\n");
      out.write("\t\t<blockquote>\r\n");
      out.write("\t\t\t<blockquote>\r\n");
      out.write("\t\t\t\t<h1><b><font size=\"7\" color=\"#800000\" face=\"Chiller\">Inbox</font><font size=\"6\" color=\"#800000\" face=\"Chiller\">\r\n");
      out.write("\t\t\t\t</font></b><font color=\"#000080\" face=\"French Script MT\"><b>\r\n");
      out.write("\t\t\t\t<font face=\"Chiller\" color=\"#800000\" size=\"6\">\r\n");
      out.write("\t\t\t\t<input type=hidden name=\"index\" size=\"20\"></font></b></font>\r\n");
      out.write("\t\t\t\t</h1>\r\n");
      out.write("\t\t\t</blockquote>\r\n");
      out.write("\t\t\t<div style=\"position: absolute; width: 317px; height: 59px; z-index: 1; left: 459px; top: 0px\" id=\"layer5\">\r\n");
      out.write("\t\t\t\t<div style=\"position: absolute; width: 55px; height: 24px; z-index: 1; left: 129px; top: 26px\" id=\"layer6\">[<b><font size=\"2\">\r\n");
      out.write("\t\t\t\t\t<a href=\"logout.jsp\">Logout</a> </font></b>]</div><center>\r\n");
      out.write("\t\t\t\t<font size=\"4\" face=\"Bell MT\" color=\"#000080\">");
      out.print(session.getAttribute("user"));
      out.write("</font></center>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t</blockquote>\r\n");
      out.write("\t</blockquote>\r\n");
      out.write("<p>\r\n");
      out.write("</p>\r\n");
      out.write("<!--<table  width=\"663\">\r\n");
      out.write("<tr><td>-->\r\n");
      out.write("<table  width=\"778\">\r\n");
      out.write("<tr><td width=\"772\" background=\"image/b11.jpg\" height=\"50\">\r\n");
      out.write("<blockquote>\r\n");
      out.write("\t\r\n");
      out.write("\t<center>\r\n");
      out.write("\t<blockquote>\r\n");
      out.write("\t\t<blockquote>\r\n");
      out.write("\t\t\t<blockquote>\r\n");
      out.write("\t\t\t\t<pre><font face=\"Baskerville Old Face\"><b><a href=\"inbox.jsp\" ><font size=\"4\" color=\"#800080\">InBox</font></a></b></font><font size=\"5\"><font color=\"#800080\">       </font></font><b><a href=\"phisbox.jsp\"><font color=\"#800080\" face=\"Baskerville Old Face\" size=\"4\">PhisBox</font></a></b><font color=\"#800080\" size=\"5\">      </font><b><a href=\"compose.jsp\"><font size=\"4\" color=\"#800080\" face=\"Baskerville Old Face\">ComposeMail</font></a><font size=\"4\" color=\"#800080\" face=\"Baskerville Old Face\">  </font></b></pre>\r\n");
      out.write("\t\t\t</blockquote>\r\n");
      out.write("\t\t</blockquote>\r\n");
      out.write("\t</blockquote>\r\n");
      out.write("\t</center>\r\n");
      out.write("\r\n");
      out.write("<!--<td>-->\r\n");
      out.write("</blockquote>\r\n");
      out.write("</tr>\r\n");
      out.write("<tr>\r\n");
      out.write("<td height=\"136\">\r\n");
      out.write("\t<blockquote>\r\n");
      out.write("\t\t<p>&nbsp;</p>\r\n");
      out.write("\t\t<table border=\"1\" width=\"85%\" id=\"table1\" cellspacing=\"1\">\r\n");
      out.write("\t\t\t<tr>\r\n");
      out.write("\t\t\t\t<th width=\"27\"><font color=\"#AA6600\" size=\"4\">\r\n");
      out.write("\t\t\t\t<input type=\"checkbox\" name=\"C1\" value=\"ON\" style=\"font-weight: 700\"></font></th>\r\n");
      out.write("\t\t\t\t<th width=\"246\"><b><font size=\"4\" color=\"#008000\">Sender</font></b></th><th><b><font size=\"4\" color=\"#008000\">Subject</font></b></th><th><b><font size=\"4\" color=\"#008000\">Date</font></b></th></tr>");
 Appn.Mail m=new Appn.Mail(); 
      out.write("\r\n");
      out.write("        ");
 mf=m.receive((String)application.getInitParameter("server"),(String)session.getAttribute("user"),(String)session.getAttribute("pwd")); 
      out.write("\r\n");
      out.write("\t   ");
 session.setAttribute("allmsg",mf) ; 
      out.write("\r\n");
      out.write("       ");
 for(int i=0;i<mf.length;i++){ 
      out.write("\r\n");
      out.write("        \t\t\t\t");
 String fr=mf[i].from; 
      out.write("\r\n");
      out.write("\t\t\t");
boolean ok=true; 
      out.write("\r\n");
      out.write("\t\t\t");
if(!(mf[i].sp).equals("")){ 
      out.write("\r\n");
      out.write("\t\t\t");
fr=mf[i].sp; 
      out.write("\r\n");
      out.write("\t\t\t");
 ok=false; 
      out.write("\r\n");
      out.write("\t\t\t");
} 
      out.write("\r\n");
      out.write("\t\t\t");
 if(ok){
      out.write("\r\n");
      out.write("\t\t\t");
 fr=fr.replace("@"+(String)application.getInitParameter("server"),"@global.com"); 
      out.write("\r\n");
      out.write("            ");
} 
      out.write("\t\t\t\r\n");
      out.write("\t\t\t\r\n");
      out.write("\t\t\t\r\n");
      out.write("\t");
String status[]={"Phising Mail","Possible of Phising","Not Phising"}; 
      out.write('\r');
      out.write('\n');
      out.write('	');
int s=0; 
      out.write('\r');
      out.write('\n');
      out.write('	');
 String domain=fr.substring(fr.lastIndexOf("@")+1,fr.lastIndexOf(".")); 
      out.write('\r');
      out.write('\n');
      out.write('	');
Appn.Analyzer ob=new Appn.Analyzer();
      out.write('\r');
      out.write('\n');
      out.write('	');
s=ob.analyze(mf[i].msg,(String)application.getInitParameter("server"),domain)+1;
      out.write('\r');
      out.write('\n');
      out.write('	');
mf[i].msg=ob.changeLink(mf[i].msg,(String)application.getInitParameter("server"),domain);
      out.write("\r\n");
      out.write("\t\t\t\r\n");
      out.write("\t\t\t<tr>\r\n");
      out.write("\t\t\t\t<td width=\"27\">\r\n");
      out.write("\t\t\t\t<p align=\"center\"><font color=\"#D27E00\" size=\"3\">\r\n");
      out.write("\t\t\t\t<input type=\"checkbox\" name=\"C1\" value=\"ON\" style=\"font-weight: 700\"></font></td>\r\n");
      out.write("\t\t\t\t<td width=\"246\"><b><font color=\"#D27E00\">");
      out.print(fr);
      out.write("</font></b></td><td><b><font color=\"#D27E00\">");
      out.print(mf[i].subject );
      out.write("</font></b></td>\r\n");
      out.write("\t\t\t\t<td width=\"169\"><b><font color=\"#D27E00\">");
      out.print(mf[i].date );
      out.write("</font></b></td></tr>");
 } 
      out.write("\r\n");
      out.write("\t\t</table>\r\n");
      out.write("\t</blockquote>\r\n");
      out.write("<!--</tr>\r\n");
      out.write("</table>-->\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("</form>\r\n");
      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
        else log(t.getMessage(), t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
