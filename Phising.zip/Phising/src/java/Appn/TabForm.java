package Appn;


public class TabForm
{
	public String no,name,type;
	TabForm(String n,String na,String ty)
	{
		no=n;
		name=na;
		type=ty;
	}
}