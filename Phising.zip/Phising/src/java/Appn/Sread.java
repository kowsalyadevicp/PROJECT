package Appn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class Sread
{
	public Vector getTable(String s)
	{
		Vector v=new Vector();
		
		try
		{
			int sno=0;
			Class.forName("com.mysql.jdbc.Driver"); 
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:4400/SIC","root","oracle");  	
            Statement st=conn.createStatement();  
            ResultSet rs=st.executeQuery("select * from list");            
	while(rs.next())
			{
				TabForm tf=new TabForm(""+(++sno),rs.getString("name"),rs.getString("role"));
				v.add(tf);
				
			}
			
			st.close();
		conn.close();
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
	
	}

		return v;
	}

public static void main(String a[])
{
	Vector v=new Sread().getTable("gts11");
	System.out.println(v.size());
}
}