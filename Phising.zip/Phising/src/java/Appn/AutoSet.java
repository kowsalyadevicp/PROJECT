package Appn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class AutoSet
{
	public void check(String name,String type,String server)
	{	
		boolean exist=false;
		try
		{
			Class.forName("com.mysql.jdbc.Driver"); 
Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:4400/SIC","root","oracle");  	
            //PreparedStatement st = conn.prepareStatement("Select * from MEMBER WHERE id = '"+member.id+"'");
	Statement stmt=conn.createStatement();  
ResultSet rs=stmt.executeQuery("Select * from LIST WHERE name= '"+name+"'");  	
        //DriverManager.registerDriver( new oracle.jdbc.driver.OracleDriver() );
			//Connection conn = DriverManager.getConnection( "jdbc:oracle:thin:@"+server,"root","oracle" );
			//PreparedStatement st = conn.prepareStatement("Select * from LIST WHERE name= '"+name+"'");
			//ResultSet rs = st.executeQuery();
			while(rs.next())
			{
				exist=true;
			}
			if(!exist)
			{
				String query="insert into LIST values('"+name+"','"+type+"')";
				stmt.executeUpdate(query);
				
			}
			stmt.close();
		conn.close();
		
	}
	catch(Exception e)
	{
		e.printStackTrace();
		
	}

	
	}
	

}