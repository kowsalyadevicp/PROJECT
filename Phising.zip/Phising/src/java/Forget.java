import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.*;
import javax.servlet.http.*;

import Appn.Member;

import oracle.jdbc.pool.OracleDataSource;
public class Forget extends HttpServlet
{
	String password;
public void doPost(HttpServletRequest request,HttpServletResponse response)
throws ServletException, IOException
{
PrintWriter out = response.getWriter();
Member member=new Member();
member.id=request.getParameter("p1");
member.secq=request.getParameter("p2");
member.seca=request.getParameter("p3");

boolean result=search(member);
if(result)
{
	
	RequestDispatcher rq=request.getRequestDispatcher("forget.jsp");
	request.setAttribute("msg","U r member.Ur Password is "+password);
	rq.include(request,response);
}
else
{
	RequestDispatcher rq=request.getRequestDispatcher("forget.jsp");
	request.setAttribute("msg","Invalid Entry,Try again");
	rq.include(request,response);
}
}
public boolean search(Member member)
{
	boolean exist=false;
	try
	{
            Class.forName("com.mysql.jdbc.Driver"); 
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:4400/SIC","root","oracle");  	
            Statement st=conn.createStatement();  
            ResultSet rs=st.executeQuery("select * from member");  			
	
		//DriverManager.registerDriver( new oracle.jdbc.driver.OracleDriver() );
		//Connection con = DriverManager.getConnection( "jdbc:oracle:thin:@"+getServletConfig().getServletContext().getInitParameter("server"),"root","oracle" );
		//Statement st=con.createStatement();
               // ResultSet rs=st.executeQuery("Select * from MEMBER");
	while(rs.next())
	{
		if(member.id.equals(rs.getString(2))&&member.secq.equals(rs.getString(4))&&member.seca.equals(rs.getString(5)))
				{
			password=rs.getString(3);
			exist=true;
			break;
				}
	}
	st.close();
	conn.close();
	
	}
	catch(Exception e)
	{
		return false;
	}
	
	return exist;
}


}