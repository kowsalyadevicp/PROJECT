/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kmp;
import java.io.*;


/**
 *
 * @author kowsalyadevicp
 */
public class KMP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int k;
        FileReader in =null;
        FileWriter out=null;
        try{
            in=new FileReader("C:\\Users\\kowsalyadevicp\\Desktop\\input.txt");
            out=new FileWriter("C:\\Users\\kowsalyadevicp\\Desktop\\output.txt");
            
            while((k=in.read())!=-1)
            {
                 out.write(k);
            }
        }
       finally {
         if (in != null) {
            in.close();
         }
         if (out != null) {
            out.close();
         }
        }
    }   
}
