/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kmp;

/**
 *
 * @author kowsalyadevicp
 */
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.*;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
 
/** Class KnuthMorrisPratt **/
        
public class KnuthMorrisPratt
{
    /** Failure array **/
    private int[] failure;
    BufferedWriter out;
    /** Constructor
     * @param text **/
    public KnuthMorrisPratt(String text, String pat) throws IOException
    {
        failure = new int[pat.length()];
       // System.out.println(text+"------"+pat);
        fail(pat);
        int pos = posMatch(text, pat);
        if (pos != -1 && notin(pat))
        {
         out = new BufferedWriter(new FileWriter("G:\\1FYP\\output.txt",true));
         out.append(pat+"  ");
         //out.append(text.substring(pos, text.indexOf(" ")));
         out.close();
        } 
    }
    boolean notin(String s)
    {
        if(s.equals("and")||s.equals("by")||s.equals("an")||s.equals("thi")||s.equals("s")|| s.equals("is")|| s.equals("this")|| s.equals("us")|| s.equals("the")|| s.equals("ar")||s.equals("or")||s.equals("to")||s.equals("a"))
            return false;
        else
            return true;
            
    }
    /** Failure function for a pattern **/
      private void fail(String pat)
    {
        int n = pat.length();
        failure[0] = -1;
        for (int j = 1; j < n; j++)
        {
            int i = failure[j - 1];
            while ((pat.charAt(j) != pat.charAt(i + 1)) && i >= 0)
                i = failure[i];
            if (pat.charAt(j) == pat.charAt(i + 1))
                failure[j] = i + 1;
            else
                failure[j] = -1;
        }
        
    }
    /** Function to find match for a pattern **/
    private int posMatch(String text, String pat)
    {
        int i = 0, j = 0;
        int lens = text.length();
        int lenp = pat.length();
        while (i < lens && j < lenp)
        {
            
            //System.out.println("text  "+text.charAt(i)+" pattern   "+ pat.charAt(j));
            //System.out.println("i :"+i+" j:"+j);
            if (text.charAt(i) == pat.charAt(j))
            {
                i++;
                j++;
            }
            else if (j == 0)
                i++;
            else
                j = failure[j - 1] + 1;
        }
        return ((j == lenp) ? (i - lenp) : -1);
    }
    /** Main Function **/
    public static void main(String[] args) throws IOException
    {    
        BufferedReader javadic=new BufferedReader(new FileReader("G:\\1FYP\\javadict.txt"));
        BufferedReader stem=new BufferedReader(new FileReader("G:\\1FYP\\stemm.txt"));
        StringBuilder sb = new StringBuilder();
         
        //FileWriter out=new FileWriter("C:\\Users\\kowsalyadevicp\\Desktop\\output.txt");
        String line = javadic.readLine();
        while (line != null) 
        {
            sb.append(line).append("\n");
            line = javadic.readLine();
        }
        String text = sb.toString();
        StringBuilder sp = new StringBuilder();
        String lin = stem.readLine();
        while (lin != null) 
        {
            sp.append(lin).append("\n");
            lin = stem.readLine();
        }
        String pattern = sp.toString();
        StringTokenizer st = new StringTokenizer(pattern," ");
        while ( st.hasMoreTokens() )
        {
             String token = (String)st.nextToken();
             KnuthMorrisPratt kmp = new KnuthMorrisPratt(text, token); 
        }      
    }
}
