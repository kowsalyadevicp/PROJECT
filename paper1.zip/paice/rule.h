#define MAXSTEMSIZE 10
#define MINSTEMSIZE 3
#define MAXWDSZ 25 /* Maximum length of word stemmable */
#define MAXKEYSZ 12 /* Maximum length of suffix */
#define MAXSUFFSZ 8 /* Maximum length of suffix */
struct rule {
  char text[MAXWDSZ]; /* To return stemmer output */
  char keystr[MAXKEYSZ]; /* Key string,ie,suffix to remove */
  char repstr[MAXSUFFSZ]; /* string to replace deleted letters */
  char intact; /* Boolean-must word be intact? */
  char cont; /* Boolean-continue with another rule? */
  int rulenum; /* Line number of rule in rule list file */
  char protect; /* Boolean-protect this ending? */
  char deltotal; /* Delete how many letters? */
  struct rule *next; /* Next item in linked list */
};